package com.example.baza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BazaApplicationTests {

    @Test
    void contextLoads() {
    }

}
