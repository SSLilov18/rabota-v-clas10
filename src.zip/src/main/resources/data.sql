INSERT INTO Player (ID, Name,Nationality, Birth_date, Titles)
VALUES(1, 'Raya', 'Bulagarian', '2004-05-04', 18);
INSERT INTO Player (ID, Name,Nationality, Birth_date, Titles)
VALUES(2, 'Kraska Ukraska', 'Bulagarian', '2004-03-21', 90);
INSERT INTO Player (ID, Name,Nationality, Birth_date, Titles)
VALUES(3, 'Stan4o', 'Bulagarian', '2004-11-17', 17);
