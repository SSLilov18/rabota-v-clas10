package com.example.baza;

import java.sql.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BazaApplication {

    public static void main(String[] args) {
        SpringApplication.run(BazaApplication.class, args);
    }

}
